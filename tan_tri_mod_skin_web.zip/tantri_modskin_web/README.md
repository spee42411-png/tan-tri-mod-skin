# TẤN TRÍ MOD SKIN — Web catalogue

Website Flask dùng danh mục `aov_skins.json` từ `modskinlq-main.zip` bạn cung cấp. Bản hiện tại cung cấp tra cứu tướng/skin, API JSON, quản trị danh mục bổ sung và SQLite. Không chỉnh sửa, đóng gói hoặc cài đặt tài nguyên vào game.

## Chạy trên Windows
1. Cài Python 3.11+ từ https://www.python.org/downloads/ (chọn Add Python to PATH).
2. Giải nén ZIP này.
3. Mở thư mục vừa giải nén, gõ `cmd` vào thanh địa chỉ File Explorer rồi Enter.
4. Chạy:

```bat
py -m venv .venv
.venv\Scripts\activate
py -m pip install -r requirements.txt
set SECRET_KEY=doi-chuoi-bi-mat-dai-ngau-nhien
set ADMIN_PASSWORD=dat-mat-khau-quan-tri-manh
py app.py
```

5. Mở http://127.0.0.1:5000
6. Trang quản trị: http://127.0.0.1:5000/admin

## Đưa website lên Render
1. Tạo tài khoản GitHub và Render.
2. Tạo repository GitHub mới, tải toàn bộ nội dung thư mục này lên (không tải `Resources.zip` 140 MB hoặc các gói game gốc lên GitHub).
3. Trong Render chọn **New + → Blueprint**, kết nối repository và chọn file `render.yaml`.
4. Khi Render hỏi `ADMIN_PASSWORD`, nhập mật khẩu quản trị mạnh. `SECRET_KEY` được Render tự tạo.
5. Deploy và mở URL `.onrender.com` được cấp.

Lưu ý: ổ đĩa của dịch vụ Render thông thường không đảm bảo lưu SQLite bền vững sau khi khởi động lại/deploy. Bản demo phù hợp kiểm tra giao diện và danh mục; nếu cần quản trị dữ liệu lâu dài, hãy gắn Persistent Disk hoặc chuyển DB sang PostgreSQL. Ảnh minh họa phải là URL ảnh bạn có quyền sử dụng.

## API
- `GET /health`
- `GET /api/stats`
- `GET /api/heroes?q=krixi`
- `GET /api/skins?hero=Krixi`
- `GET /api/skins?q=thần thoại`

## Nguồn dữ liệu
Danh sách 123 tướng / 1.159 skin được sao chép từ `modskinlq-main/Appearance/aov_skins.json`. ZIP `Resources.zip` chứa tài nguyên game nhị phân và chưa được đưa lên máy chủ web. README nguồn ghi công cụ Python V1.5 có 4/7 tính năng hoàn thành; website này không khẳng định hay thực thi các tính năng mod đó.
